class Book < ApplicationRecord
  belongs_to :user
  # devise :database_authenticatable, :registerable,
        # :recoverable, :rememberable, :validatable
  
  validates :title, presence: true
  validates :body, presence: true
end
