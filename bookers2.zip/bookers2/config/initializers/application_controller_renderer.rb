# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '797ffbf94a26a6f15f3c9f4ae4aaefc46f9b188bc6be66d23b62f3563692d17382637da1a4a0c8d0820fe61ab8053b57a004797b1c9c1b93e10a9168465b2928'